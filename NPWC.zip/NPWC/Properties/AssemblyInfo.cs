using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("IISI")]
[assembly: AssemblyTrademark("IISI")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyProduct("NPWC")]
[assembly: AssemblyCopyright("IISI Copyright ©  2014")]
[assembly: AssemblyDescription("After main Work done do rename")]
[assembly: AssemblyTitle("NPWC")]
[assembly: ComVisible(false)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: CompilationRelaxations(8)]
[assembly: AssemblyFileVersion("1.0.1.8")]
[assembly: Guid("febab3c6-3d7b-481f-b185-16b416cd27d6")]
[assembly: AssemblyVersion("1.0.1.8")]
