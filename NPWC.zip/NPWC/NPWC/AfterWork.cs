using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

namespace NPWC
{
	[DesignerGenerated]
	public class AfterWork : Form
	{
		private IContainer components;

		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		internal virtual Label Label1
		{
			get
			{
				return _Label1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				_Label1 = value;
			}
		}

		public AfterWork()
		{
			base.Load += new EventHandler(AfterWork_Load);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		[System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NPWC.AfterWork));
			Label1 = new System.Windows.Forms.Label();
			SuspendLayout();
			Label1.AutoSize = true;
			Label1.BackColor = System.Drawing.Color.Transparent;
			Label1.Font = new System.Drawing.Font("標楷體", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 136);
			Label1.ForeColor = System.Drawing.Color.Red;
			System.Drawing.Point point2 = Label1.Location = new System.Drawing.Point(36, 53);
			Label1.Name = "Label1";
			System.Drawing.Size size2 = Label1.Size = new System.Drawing.Size(331, 19);
			Label1.TabIndex = 0;
			Label1.Text = "系統更新中請稍待..............";
			System.Drawing.SizeF sizeF2 = AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.White;
			BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			size2 = (ClientSize = new System.Drawing.Size(392, 135));
			ControlBox = false;
			Controls.Add(Label1);
			Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			Name = "AfterWork";
			StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			ResumeLayout(false);
			PerformLayout();
		}

		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void AfterWork_Load(object sender, EventArgs e)
		{
			Show();
			Application.DoEvents();
			int num = 0;
			string text = Interaction.GetSetting("PRSB", "main", "TestPath", Application.StartupPath);
			Process[] processesByName = Process.GetProcessesByName("NPWB");
			checked
			{
				while (processesByName.Length > 0)
				{
					Thread.Sleep(1000);
					processesByName = Process.GetProcessesByName("NPWB");
					num++;
					if (num > 10)
					{
						try
						{
							processesByName[0].Kill();
						}
						catch (Exception ex)
						{
							ProjectData.SetProjectError(ex);
							Exception ex2 = ex;
							ProjectData.ClearProjectError();
						}
						num = 0;
					}
				}
				string[] files = Directory.GetFiles(text, "$*");
				try
				{
					int num2 = files.Length - 1;
					for (int i = 0; i <= num2; i++)
					{
						string text2 = Strings.Replace(files[i], "$", "");
						string text3 = text2 + ".bak";
						if (File.Exists(text2))
						{
							if (File.Exists(text3))
							{
								File.Delete(text3);
							}
							File.Move(text2, text3);
						}
						File.Move(files[i], text2);
					}
				}
				catch (Exception ex3)
				{
					ProjectData.SetProjectError(ex3);
					Exception ex4 = ex3;
					Interaction.MsgBox("系統啟動時發生錯誤，可能是權限問題!\r\n請改以系統管理員身份重新再執行本系統", MsgBoxStyle.Exclamation, "業務資料傳輸系統");
					ProjectData.EndApp();
					ProjectData.ClearProjectError();
				}
				if (Operators.CompareString(Strings.Right(text, 1), "\\", false) != 0)
				{
					text += "\\";
				}
				if (Operators.CompareString(Interaction.GetSetting("PRSB", "main", "E2U"), "IISI", false) == 0)
				{
					if ((Screen.PrimaryScreen.Bounds.Width < 1010) | (Screen.PrimaryScreen.Bounds.Height < 680))
					{
						if (File.Exists(text + "PWNSL.exe"))
						{
							Interaction.Shell(text + "PWNSL.exe", AppWinStyle.NormalFocus);
						}
						else
						{
							Interaction.Shell(text + "PWNS.exe", AppWinStyle.NormalFocus);
						}
					}
					else
					{
						Interaction.Shell(text + "PWNS.exe", AppWinStyle.NormalFocus);
					}
				}
				else
				{
					Interaction.Shell(text + "NPWB.exe", AppWinStyle.NormalFocus);
				}
				ProjectData.EndApp();
			}
		}
	}
}
